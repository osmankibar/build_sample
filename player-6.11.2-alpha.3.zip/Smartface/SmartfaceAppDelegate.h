//
//  SmartfaceAppDelegate.h
//  Smartface
//
//  Copyright 2011 Smartface. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SmartfaceAppDelegate : NSObject <UIApplicationDelegate> {

}

@end
